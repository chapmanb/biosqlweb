"""Internationalization and Localization functionality"""
from pylons.i18n.translation import *
